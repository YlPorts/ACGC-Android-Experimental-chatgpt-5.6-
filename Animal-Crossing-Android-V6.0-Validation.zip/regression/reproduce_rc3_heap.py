#!/usr/bin/env python3
"""Reproduce the known RC3 ARM64 null system heap using the unchanged RC3 sources.
Requires GCC's AArch64 cross compiler and qemu-user. Does not run Android/the game.
"""
import argparse
from pathlib import Path
import subprocess
import shlex
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source',type=Path,required=True,help='checkout of v6.0-rc3')
p.add_argument('--output',type=Path,required=True)
p.add_argument('--cc',default='aarch64-linux-gnu-gcc')
p.add_argument('--cxx',default='aarch64-linux-gnu-g++')
p.add_argument('--runner',default='qemu-aarch64')
a=p.parse_args();root=a.source.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert sha=='7389bda585ceeeba49f5c713152cf5e890053d8d','Expected the exact RC3 commit'
fixture=Path(__file__).with_name('heap_boot_test-rc3-repro.cpp')
flags=['-DTARGET_PC','-D_LANGUAGE_C','-DF3DEX_GBI_2','-DVERSION=0','-DPC_NATIVE_64','-Iinclude','-Ipc/include','-Ipc/lib/glad/include','-Iandroid/SDL/include','-fno-strict-aliasing','-fwrapv','-g','-ffunction-sections','-fdata-sections','-static']
objects=[]
for name in ['pc_os','pc_dvd']:
 obj=out/(name+'.o');subprocess.run(shlex.split(a.cc)+['-std=gnu11']+flags+['-c',f'pc/src/{name}.c','-o',str(obj)],cwd=root,check=True);objects.append(str(obj))
sources=['src/static/JSystem/JKernel/'+s+'.cpp' for s in ['JKRExpHeap','JKRHeap','JKRDisposer']]+['src/static/JSystem/JSupport/JSUList.cpp','src/static/JSystem/JFramework/JFWSystem.cpp',str(fixture)]
exe=out/'heap_boot_test';subprocess.run(shlex.split(a.cxx)+['-std=c++17']+flags+sources+objects+['-Wl,--gc-sections','-o',str(exe)],cwd=root,check=True)
r=subprocess.run(shlex.split(a.runner)+[str(exe),'--legacy-budget'],cwd=out,text=True,capture_output=True,timeout=30)
(out/'rc3-reproduction.log').write_text(r.stdout+r.stderr)
assert r.returncode in (-6,134) and 'system=(nil)' in r.stderr and 'cannot alloc memory' in r.stderr, 'Known RC3 failure was not reproduced'
print(r.stderr)
print('Reproduced RC3: system heap creation fails on AArch64; this is not a passing game test.')
