"""Reproduce the color regression using RC4's exact GBI header and live renderer.
Run after tools/validation/run_gles_tests.py (requires git, EGL/Mesa and C++).
Only an isolated temporary header/Emu64 object changes, never the checkout.
"""
import os,resource,shlex,subprocess,sys,hashlib
from pathlib import Path
ROOT=Path('/workspace/ACGC-Android')
OUT=Path('/workspace/validation/rc5/gles')
SHA='71a9b2d7b3d2aa048fa3f0d59ac61e8e5c0b9d6d'
overlay=OUT/'rc4-header';(overlay/'PR').mkdir(parents=True,exist_ok=True)
header=Path(sys.argv[1]).read_bytes() if len(sys.argv)>1 else subprocess.check_output(['git','show',SHA+':include/PR/gbi.h'],cwd=ROOT)
(overlay/'PR/gbi.h').write_bytes(header)
assert b'unsigned long\tcolor' in header
assert hashlib.sha256(header).hexdigest()=='25e1ae6389f2907bfb6d5ed6f54ded79a79fa2b252f653145d2caa280b83149f'
flags=['-std=gnu++17','-O1','-g','-DTARGET_PC','-DTARGET_ANDROID','-DPC_NATIVE_64','-D_LANGUAGE_C','-DF3DEX_GBI_2','-DVERSION=0','-fno-strict-aliasing','-fwrapv','-ffunction-sections','-fdata-sections','-I'+str(overlay),'-Iinclude','-Ipc/include','-U_GNU_SOURCE','-D_POSIX_C_SOURCE=200809L','-fpermissive','-Wno-narrowing']
flags+=shlex.split(subprocess.check_output(['pkg-config','--cflags','sdl2','egl','glesv2'],text=True))
old=OUT/'emu64-rc4-color.o'
subprocess.run(['c++',*flags,'-c','src/static/libforest/emu64/emu64.c','-o',old],cwd=ROOT,check=True)
objects=[p for p in OUT.glob('*.o') if p.name not in ('emu64.o','emu64-rc4-color.o')]+[old]
libs=shlex.split(subprocess.check_output(['pkg-config','--libs','sdl2','egl','glesv2'],text=True))
exe=OUT/'rc4_color_regression'
subprocess.run(['c++',*objects,'-Wl,--gc-sections',*libs,'-lm','-o',exe],check=True)
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
env=dict(os.environ,LIBGL_ALWAYS_SOFTWARE='1',MESA_SHADER_CACHE_DIR=str(OUT/'mesa-cache'))
r=subprocess.run([exe],cwd=OUT,env=env,text=True,capture_output=True,timeout=120)
log=r.stdout+r.stderr
(OUT/'rc4-before.log').write_text(log)
assert r.returncode in (-6,134),(r.returncode,log)
assert 'Emu64 primitive color (RC4 black regression): RGBA=0,0,0' in log,log
print(log)
print('Expected RC4 black pixel/assertion reproduced; corrected header passes both shader modes.')
